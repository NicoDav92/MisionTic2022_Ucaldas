# G70H
Repositorio para Documentos del Proyecto

Repositorio Proyecto de Desarrollo de Software 
Se uttilizará React + Vite + MongoDB para su desarrollo 

Estructura de carpetas y archivos  conforme a la siguiente estructura

AppWeb --- Carpeta Main del Proyecto
   ----- /src/main + App
   ----- /src/assets/css
   ----- /src/components/Footer +Header + Navigation
   ----- /src/Layout/Layout
   ----- /src/pages/Main + Vite

           
TestGitHub / Carpeta de Pruebas Desallolladores.
